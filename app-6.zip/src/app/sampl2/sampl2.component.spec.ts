import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Sampl2Component } from './sampl2.component';

describe('Sampl2Component', () => {
  let component: Sampl2Component;
  let fixture: ComponentFixture<Sampl2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [Sampl2Component]
    });
    fixture = TestBed.createComponent(Sampl2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
