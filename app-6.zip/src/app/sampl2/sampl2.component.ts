import { Component } from '@angular/core';

@Component({
  selector: 'app-sampl2',
  templateUrl: './sampl2.component.html',
  styleUrls: ['./sampl2.component.css']
})
export class Sampl2Component {
  user = {
    firstName: '',
    lastName: '',
    email: '',
    password: ''
  };

  register() {
    // Replace this with your actual registration logic
    console.log('User registered:', this.user);
  }
}
