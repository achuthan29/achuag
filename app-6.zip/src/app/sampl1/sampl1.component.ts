import { Component } from '@angular/core';
@Component({
  selector: 'app-sampl1',
  templateUrl: './sampl1.component.html',
  styleUrls: ['./sampl1.component.css']
})
export class Sampl1Component {
  username: string = '';
  password: string = '';
  loginAttempts: number = 3;
  loginFailed: boolean = false;
  loginSuccess: boolean = false;

  login() {
    // Replace the condition with your actual authentication logic
    if (this.username === 'Achuthan29' && this.password === '2575756') {
      this.loginSuccess = true;
      this.loginFailed = false;
    } else {
      this.loginAttempts--;

      if (this.loginAttempts === 0) {
        // Disable login button after 3 failed attempts
        document.querySelector('button')?.setAttribute('disabled', 'true');
      }

      this.loginFailed = true;
      this.loginSuccess = false;
    }
  }
}
