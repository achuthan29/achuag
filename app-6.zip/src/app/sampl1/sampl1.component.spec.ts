import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Sampl1Component } from './sampl1.component';

describe('Sampl1Component', () => {
  let component: Sampl1Component;
  let fixture: ComponentFixture<Sampl1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [Sampl1Component]
    });
    fixture = TestBed.createComponent(Sampl1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
