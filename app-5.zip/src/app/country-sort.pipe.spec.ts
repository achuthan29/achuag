import { CountrySortPipe } from './country-sort.pipe';

describe('CountrySortPipe', () => {
  it('create an instance', () => {
    const pipe = new CountrySortPipe();
    expect(pipe).toBeTruthy();
  });
});
