import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'agas3';
  fahrenheitTemperature: number = 0; 
  celsiusTemperature: number = 0;
  originalString: string = ' ';
}
