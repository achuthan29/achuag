import { Component} from '@angular/core';
@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent {
    msg:string="";
    rnd:number=0;
    generateRandom(){
      this.rnd=Math.random();
    }
    GetDataFromChild(str:string){
      this.msg=str;
    }
}
