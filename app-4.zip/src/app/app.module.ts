import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReadDirective } from './read.directive';
import { NumberDirective } from './number.directive';
import { WhitespaceDirective } from './whitespace.directive';

@NgModule({
  declarations: [
    AppComponent,
    ReadDirective,
    NumberDirective,
    WhitespaceDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
