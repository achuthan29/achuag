import { ReadDirective } from './read.directive';

describe('ReadDirective', () => {
  it('should create an instance', () => {
    const directive = new ReadDirective();
    expect(directive).toBeTruthy();
  });
});
